// Put all the javascript code here, that you want to execute after page load.
//console.log(document.getElementsByClassName("tagline")[0]);
divs = Document.getElementsByTagName("div");
console.log(divs.getElementsByClassName("tagline"));
console.log("test");
